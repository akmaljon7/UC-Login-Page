package assignment9b;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Assignment9B {
    JFrame frame;
    Container con;
    JTextField txtLab;
    JPasswordField txtLab2;
    JButton loginButton;
    JButton txtLab3;
    JButton imgLab;
    JLabel statusLabel; 

    public Assignment9B() {
        // Initialize JFrame
        frame = new JFrame();
        frame.setTitle("University Of Cincinnati");

        // set a thumb-nail Image
        ImageIcon image = new ImageIcon("icon2.png");
        frame.setIconImage(image.getImage());

        // set location & dimension
        frame.setBounds(200, 200, 500, 500);

        // modify appearance
        con = frame.getContentPane();
        con.setLayout(null);
        Color col = new Color(0, 0, 0);
        con.setBackground(col);

        // add content
        txtLab = new JTextField();
        txtLab.setBounds(168, 108, 170, 30);
        txtLab.setFont(new Font("Times New Roman", Font.BOLD, 30));
        txtLab.setForeground(Color.lightGray);
        txtLab.setHorizontalAlignment(JTextField.CENTER);
        txtLab.setBackground(Color.white);
        txtLab.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        txtLab.setOpaque(true);

        txtLab2 = new JPasswordField();
        txtLab2.setBounds(168, 150, 170, 30);
        txtLab2.setFont(new Font("Times New Roman", Font.BOLD, 30));
        txtLab2.setForeground(Color.lightGray);
        txtLab2.setHorizontalAlignment(JTextField.LEFT);
        txtLab2.setBackground(Color.white);
        txtLab2.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        txtLab2.setOpaque(true);
        txtLab2.setEchoChar('*');

        loginButton = new JButton("Login");
        loginButton.setBounds(168, 200, 170, 30);
        loginButton.setFont(new Font("Login", Font.PLAIN, 20));
        loginButton.setBackground(Color.red);
        loginButton.setForeground(Color.white);
        loginButton.setHorizontalAlignment(JButton.CENTER);
        loginButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        loginButton.setOpaque(true);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        txtLab3 = new JButton();
        txtLab3.setBounds(168, 108, 170, 30);
        txtLab3.setText("Click Me");
        txtLab3.setFont(new Font("Times New Roman", Font.BOLD, 30));
        txtLab3.setForeground(Color.lightGray);
        txtLab3.setHorizontalAlignment(JButton.CENTER);
        txtLab3.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        txtLab3.setOpaque(true);
        txtLab3.setCursor(new Cursor(Cursor.HAND_CURSOR));

        ImageIcon img = new ImageIcon("icon2.png");
        imgLab = new JButton(img);
        imgLab.setBounds(167, 300, img.getIconWidth(), img.getIconHeight());
        imgLab.setCursor(new Cursor(Cursor.WAIT_CURSOR));

        statusLabel = new JLabel(); // Initialize statusLabel
        statusLabel.setBounds(168, 240, 300, 30);
        statusLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        statusLabel.setForeground(Color.white);
        statusLabel.setHorizontalAlignment(JLabel.CENTER);

        con.add(txtLab);
        con.add(imgLab);
        con.add(txtLab2);
        con.add(txtLab3);
        con.add(loginButton);
        con.add(statusLabel);

        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

       
        String[] validUsernames = { "user1", "user2", "user3" };
        String[] validPasswords = { "password1", "password2", "password3" };

        
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = txtLab.getText();
                String password = new String(txtLab2.getPassword());
                boolean isValid = false;
                for (int i = 0; i < validUsernames.length; i++) {
                    if (username.equals(validUsernames[i]) && password.equals(validPasswords[i])) {
                        isValid = true;
                        break;
                    }
                }

              
                if (isValid) {
                    statusLabel.setText("Successfully logged in");
                } else {
                    statusLabel.setText("Incorrect username/password");
                }
            }
        });
    }

    public static void main(String[] args) {
        new Assignment9B();
    }
}
