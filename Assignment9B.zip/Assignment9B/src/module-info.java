/**
 * 
 */
/**
 * 
 */
module Assignment9B {
	requires java.desktop;
}